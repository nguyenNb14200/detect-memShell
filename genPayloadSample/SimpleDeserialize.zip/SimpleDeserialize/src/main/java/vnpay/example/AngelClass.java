package vnpay.example;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class AngelClass extends ClassLoader {
    private final byte[] classBytes;

    public AngelClass( byte[] classBytes) {
        this.classBytes = classBytes;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        return defineClass(name, classBytes, 0, classBytes.length);
    }
}
